abstract public class Foo extends Bar
{
    public int x;
};
