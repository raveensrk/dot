#include <stdio.h>

static int foo (void)
{
  return 1;
}

int
main(void)
{
  return foo();
}
