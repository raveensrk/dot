/* u-ctags input.c */
int
main(void)
{
	return 0;
}
