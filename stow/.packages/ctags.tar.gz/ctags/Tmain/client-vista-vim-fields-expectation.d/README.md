If your change breaks this test case, notify the change
to https://github.com/liuchengxu/vista.vim.
