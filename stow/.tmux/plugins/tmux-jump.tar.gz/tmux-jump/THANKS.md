# Thanks

A place where people can comment and say how the project helped them. 

Thank you @schasse for making this project. It has really helped me move more quickly through tmux. Now it is super easy to copy and paste without using the mouse.
- @jyrodgers

---

Inspired by [THANKS.md](https://github.com/paulmolluzzo/thanks-md)
